ipython nbconvert --to markdown <notebook>.ipynb --config jekyll.py
