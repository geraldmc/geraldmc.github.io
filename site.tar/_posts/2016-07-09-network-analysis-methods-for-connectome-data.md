---
layout: post
title: Network Analysis Methods
---

Recently I had an opportunity to attend a training session with Eric Ma of MIT and have applied some of what I learned from Eric to the connectome data we've been working with. Here are some of the results of that work. 

---